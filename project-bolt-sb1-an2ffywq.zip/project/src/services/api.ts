import axios from 'axios';

// Replace this with your actual backend API URL
const API_BASE_URL = process.env.VITE_API_URL || 'https://your-backend-api.com';
const CORS_PROXY = 'https://api.allorigins.win/raw?url=';

export const api = {
  async fetchWebsiteContent(url: string): Promise<string> {
    try {
      const response = await axios.get(`${CORS_PROXY}${encodeURIComponent(url)}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching website content:', error);
      throw new Error('Failed to fetch website content. Please check the URL and try again.');
    }
  },

  async generatePreview(url: string): Promise<string> {
    try {
      return `${CORS_PROXY}${encodeURIComponent(url)}`;
    } catch (error) {
      console.error('Error generating preview:', error);
      throw new Error('Failed to generate preview');
    }
  },

  async generateApk(websiteUrl: string, appName: string): Promise<string> {
    try {
      const response = await axios.post(`${API_BASE_URL}/generate-apk`, {
        url: websiteUrl,
        name: appName
      });
      
      return response.data.downloadUrl;
    } catch (error) {
      console.error('Error generating APK:', error);
      throw new Error('Failed to generate APK. Please try again.');
    }
  }
};