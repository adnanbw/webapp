import React, { useState } from 'react';
import { Globe, Palette, Smartphone } from 'lucide-react';
import type { WebAppConfig } from '../types';
import { generateWebApp } from '../utils/webAppGenerator';

interface WebAppFormProps {
  onSubmit: (config: WebAppConfig, appUrl: string) => void;
}

export function WebAppForm({ onSubmit }: WebAppFormProps) {
  const [config, setConfig] = useState<WebAppConfig>({
    url: '',
    appName: '',
    themeColor: '#4f46e5',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validateUrl = (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!validateUrl(config.url)) {
      setError('Please enter a valid URL (including http:// or https://)');
      return;
    }

    if (!config.appName.trim()) {
      setError('Please enter an app name');
      return;
    }

    setIsLoading(true);

    try {
      const appUrl = await generateWebApp(config);
      onSubmit(config, appUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate web app. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow-sm">
      <div>
        <label htmlFor="url" className="block text-sm font-medium text-gray-700">
          Website URL
        </label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Globe className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="url"
            id="url"
            required
            className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
            placeholder="https://your-website.com"
            value={config.url}
            onChange={(e) => setConfig({ ...config, url: e.target.value })}
          />
        </div>
      </div>

      <div>
        <label htmlFor="appName" className="block text-sm font-medium text-gray-700">
          App Name
        </label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Smartphone className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            id="appName"
            required
            className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
            placeholder="My Web App"
            value={config.appName}
            onChange={(e) => setConfig({ ...config, appName: e.target.value })}
          />
        </div>
      </div>

      <div>
        <label htmlFor="themeColor" className="block text-sm font-medium text-gray-700">
          Theme Color
        </label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Palette className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="color"
            id="themeColor"
            required
            className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 h-10 sm:text-sm border-gray-300 rounded-md"
            value={config.themeColor}
            onChange={(e) => setConfig({ ...config, themeColor: e.target.value })}
          />
        </div>
      </div>

      {error && (
        <div className="text-red-600 text-sm bg-red-50 p-3 rounded-md">
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={isLoading}
        className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white 
          ${isLoading 
            ? 'bg-indigo-400 cursor-not-allowed' 
            : 'bg-indigo-600 hover:bg-indigo-700'} 
          focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
      >
        {isLoading ? 'Generating...' : 'Generate Web App'}
      </button>
    </form>
  );
}