import React from 'react';
import type { PreviewFrame as PreviewFrameType } from '../types';

interface PreviewFrameProps {
  config: { url: string };
  frame: PreviewFrameType;
}

export function PreviewFrame({ config, frame }: PreviewFrameProps) {
  return (
    <div className="relative bg-gray-800 rounded-lg overflow-hidden shadow-lg">
      <div className="flex items-center justify-start px-4 py-2 bg-gray-900">
        <div className="flex space-x-2">
          <div className="w-3 h-3 rounded-full bg-red-500" />
          <div className="w-3 h-3 rounded-full bg-yellow-500" />
          <div className="w-3 h-3 rounded-full bg-green-500" />
        </div>
      </div>
      <div 
        className="relative bg-white"
        style={{ 
          width: frame.width,
          height: frame.height,
          transform: 'scale(0.7)',
          transformOrigin: 'top left'
        }}
      >
        <div className="w-full h-full flex items-center justify-center bg-gray-50">
          <iframe
            src={`https://api.allorigins.win/raw?url=${encodeURIComponent(config.url)}`}
            title="Web App Preview"
            className="w-full h-full border-0"
            sandbox="allow-same-origin allow-scripts"
            loading="lazy"
          />
        </div>
      </div>
    </div>
  );
}