import React, { useState } from 'react';
import { ExternalLink, Download } from 'lucide-react';

interface GeneratedAppInfoProps {
  appUrl: string;
}

export function GeneratedAppInfo({ appUrl }: GeneratedAppInfoProps) {
  const [isGeneratingApk, setIsGeneratingApk] = useState(false);

  const handlePreview = () => {
    window.open(appUrl, '_blank', 'noopener,noreferrer');
  };

  const handleDownload = async () => {
    try {
      setIsGeneratingApk(true);
      
      // Trigger download by creating a temporary link
      const link = document.createElement('a');
      link.href = appUrl;
      link.download = 'webapp.apk';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
    } catch (error) {
      console.error('Error downloading APK:', error);
      alert('Failed to download APK. Please try again.');
    } finally {
      setIsGeneratingApk(false);
    }
  };

  return (
    <div className="mt-6 bg-green-50 border border-green-200 rounded-md p-4">
      <h3 className="text-lg font-medium text-green-800">Web App Generated Successfully!</h3>
      
      <div className="mt-2 text-sm text-green-700">
        <p>Your web app is ready! You can now:</p>
        <ul className="list-disc ml-5 mt-2">
          <li>Preview your web app</li>
          <li>Download the Android APK</li>
        </ul>
      </div>
      
      <div className="mt-4 flex flex-col space-y-3">
        <button
          onClick={handlePreview}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <ExternalLink className="mr-2 h-4 w-4" />
          Preview Web App
        </button>
        
        <button
          onClick={handleDownload}
          disabled={isGeneratingApk}
          className="inline-flex items-center px-4 py-2 border border-green-600 text-sm font-medium rounded-md shadow-sm text-green-600 bg-white hover:bg-green-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          {isGeneratingApk ? (
            <>
              <span className="animate-spin mr-2">⏳</span>
              Generating APK...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Download Android APK
            </>
          )}
        </button>
      </div>
    </div>
  );
}