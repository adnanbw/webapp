import React, { useState } from 'react';
import { Header } from './components/Header';
import { WebAppForm } from './components/WebAppForm';
import { PreviewFrame } from './components/PreviewFrame';
import { GeneratedAppInfo } from './components/GeneratedAppInfo';
import type { WebAppConfig, PreviewFrame as PreviewFrameType } from './types';

const PREVIEW_FRAMES: PreviewFrameType[] = [
  { device: 'mobile', width: 375, height: 667 },
  { device: 'tablet', width: 768, height: 1024 },
  { device: 'desktop', width: 1280, height: 800 },
];

function App() {
  const [config, setConfig] = useState<WebAppConfig | null>(null);
  const [appUrl, setAppUrl] = useState<string | null>(null);
  const [activeFrame, setActiveFrame] = useState<PreviewFrameType>(PREVIEW_FRAMES[0]);

  const handleSubmit = (newConfig: WebAppConfig, generatedAppUrl: string) => {
    setConfig(newConfig);
    setAppUrl(generatedAppUrl);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            Transform Your Website Into a Web App
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Convert any website into a responsive web app with just a few clicks. No coding required.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <WebAppForm onSubmit={handleSubmit} />
            {appUrl && <GeneratedAppInfo appUrl={appUrl} />}
            
            {config && (
              <div className="mt-8">
                <div className="flex space-x-4 mb-4">
                  {PREVIEW_FRAMES.map((frame) => (
                    <button
                      key={frame.device}
                      onClick={() => setActiveFrame(frame)}
                      className={`px-4 py-2 rounded-md text-sm font-medium ${
                        activeFrame.device === frame.device
                          ? 'bg-indigo-600 text-white'
                          : 'bg-white text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {frame.device.charAt(0).toUpperCase() + frame.device.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-center bg-gray-100 rounded-lg p-8">
            {config ? (
              <PreviewFrame config={config} frame={activeFrame} />
            ) : (
              <div className="text-center text-gray-500">
                <p className="text-lg">Enter your website details to see the preview</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;