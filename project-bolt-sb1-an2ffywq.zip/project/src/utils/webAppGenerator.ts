import type { WebAppConfig } from '../types';
import { api } from '../services/api';

export async function generateWebApp(config: WebAppConfig): Promise<{ previewUrl: string; downloadUrl: string }> {
  try {
    // Generate preview URL
    const previewUrl = await api.generatePreview(config.url);
    
    // Generate APK download URL
    const downloadUrl = await api.generateApk(config.url, config.appName);

    return {
      previewUrl,
      downloadUrl
    };
  } catch (error) {
    console.error('Error generating web app:', error);
    throw new Error('Failed to generate web app. Please check the URL and try again.');
  }
}