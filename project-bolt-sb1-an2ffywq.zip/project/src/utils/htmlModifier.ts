import { parse } from 'node-html-parser';
import type { WebAppConfig } from '../types';

export function modifyHtml(html: string, config: WebAppConfig, manifest: object): string {
  try {
    const root = parse(html);
    const head = root.querySelector('head');
    
    if (!head) {
      // Create head if it doesn't exist
      const headElement = parse('<head></head>');
      root.insertAdjacentHTML('afterbegin', headElement.toString());
    }
    
    // Get head again (it will exist now)
    const finalHead = root.querySelector('head');
    
    // Add base tag to handle relative URLs
    finalHead?.insertAdjacentHTML('afterbegin', `
      <base href="${config.url}">
    `);

    // Add Web App meta tags
    finalHead?.insertAdjacentHTML('beforeend', `
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <meta name="theme-color" content="${config.themeColor}">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
      <meta name="apple-mobile-web-app-title" content="${config.appName}">
      <link rel="manifest" href='data:application/json,${JSON.stringify(manifest)}'>
    `);

    const body = root.querySelector('body');
    if (!body) {
      throw new Error('Invalid HTML: No body element found');
    }

    // Add Service Worker registration
    body.insertAdjacentHTML('beforeend', `
      <script>
        if ('serviceWorker' in navigator) {
          window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js')
              .catch(error => console.error('Service worker registration failed:', error));
          });
        }
      </script>
    `);

    return root.toString();
  } catch (error) {
    console.error('Error modifying HTML:', error);
    throw new Error('Failed to modify HTML. The website might not be compatible.');
  }
}