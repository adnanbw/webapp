import type { WebAppConfig } from '../types';

export function generateManifest(config: WebAppConfig) {
  return {
    name: config.appName,
    short_name: config.appName,
    theme_color: config.themeColor,
    background_color: '#ffffff',
    display: 'standalone',
    scope: '/',
    start_url: '/',
    icons: [
      {
        src: 'icon-192x192.png',
        sizes: '192x192',
        type: 'image/png'
      },
      {
        src: 'icon-512x512.png',
        sizes: '512x512',
        type: 'image/png'
      }
    ]
  };
}