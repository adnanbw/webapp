export interface WebAppConfig {
  url: string;
  appName: string;
  themeColor: string;
  icon?: string;
}

export interface PreviewFrame {
  device: 'mobile' | 'tablet' | 'desktop';
  width: number;
  height: number;
}

export interface GeneratedApp {
  id: string;
  url: string;
  appUrl: string;
}